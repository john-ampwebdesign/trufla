<!-- pagination -->
<div class="pagination">
	<!-- removed pagination as it is not needed -->
</div>
<!-- /pagination -->
