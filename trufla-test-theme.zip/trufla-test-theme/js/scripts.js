(function ($) {
	// $(function () { 'use strict'; });
	
	if ($(window).width() >= 1120 ) { runscript = 1; }
	
	var globalResizeTimer = null;
	$('.sidebar').ready(function() {
		if ($(window).width() >= 1120 ) { runscript = 1; }
		var topd = 29;
		if (runscript > 0) {
		if(globalResizeTimer != null) window.clearTimeout(globalResizeTimer);
		globalResizeTimer = window.setTimeout(function() {
			setsidemenu(topd);
		}, 50); 
		runscript = 0;
		}
	});
	
$(window).on("scroll", function(){
  if($('.wrapper').scrollTop() <= 10){

    setsidemenu(0);
	$(window).off("scroll");
  }
});

	$(window).resize(function() {
		
		if ($(window).width() >= 1120 ) { runscript = 1; }
		if (runscript > 0 ) {
		if(globalResizeTimer != null) window.clearTimeout(globalResizeTimer);
		globalResizeTimer = window.setTimeout(function() {
			setsidemenu(0);
		}, 50);
		runscript = 0;
		}
	});
	
	function setsidemenu(topd) {
		
		var x = $('.participation').offset();
//  alert("Top: " + x.top + " Left: " + x.left);
		var x = x.top - topd;
		var xlimit = $('.widget_sidebar_entries').height() + 335;
		var y =  $('.participation').height();
		var y2 =  $('.benefits').height();
		var y= y + y2 + 193;
		if (xlimit >= x ) { x = xlimit + 100; }
 	
	console.dir('x' + x);
	console.dir('xlimit' + xlimit);
	console.dir('y' + y);
	$('#nav_menu-2').css({'top' : x + 'px', 'height' : y + 'px'});
	};

})(jQuery, this);
// starter js file just in case some javascript is needed later.